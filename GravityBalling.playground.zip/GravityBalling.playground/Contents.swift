/* Welcome to my project!. "Gravity Balling" is a simple game created by me (Kang Min Seong) to explore interesting features of SceneKit. The Playground project is created for 500x500 size, and other sizes can distort the game view. My apologies if this lead to inconviniences.*/
import SpriteKit
import SceneKit
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
let view1 = GameView()
view1.allowsCameraControl = false
PlaygroundPage.current.liveView = view1

